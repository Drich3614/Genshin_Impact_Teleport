

## Local Specialties

| AddTime    | Img                                                | Name/ID             | World  | Author/ID         | NOTE         |
| ---------- | -------------------------------------------------- | ------------------- | ------ | ----------------- | -------------|
| 2023/01/26 | ![GlazeLily](../img/icons/GlazeLily.png) | [Glaze Lily](https://github.com/Sam5440/Genshin_Impact_Teleport/tree/download/ManualCollectPoint/LocalSpecialties#glazelilyzip) | Teyvat | [Drich#6666](https://github.com/Drich3614) | 41 Lilies |
| 2022/10/11 | ![HennaBerry](../img/icons/HennaBerry.png) |[Henna Berry](https://github.com/Sam5440/Genshin_Impact_Teleport/tree/download/ManualCollectPoint/LocalSpecialties#hennaberryzip)[^4] | Teyvat | jdbddbhd#9874 | / |
| 2022/10/10 | ![KalpalataLotus](../img/icons/KalpalataLotus.png) | [Kalpalata Lotus](https://github.com/Sam5440/Genshin_Impact_Teleport/tree/download/ManualCollectPoint/LocalSpecialties#kalpalatalotuszip) | Teyvat | jdbddbhd#9874 | Total is 64+2+5.P/S:ID25 and ID26 you need pick up yourself,and 5 of all you need to buy from npc. |
| 2022/10/12 | ![KalpalataLotus](../img/icons/KalpalataLotus.png) | [Kalpalata Lotus#2](https://github.com/Sam5440/Genshin_Impact_Teleport/tree/download/ManualCollectPoint/LocalSpecialties#kalpalatalotus2zip) | Teyvat | civicmanan#2171 | 66 pcs |
| 2022/10/11 | ![NilotpalaLotus](../img/icons/NilotpalaLotus.png) | [Nilotpala Lotus](https://github.com/Sam5440/Genshin_Impact_Teleport/tree/download/ManualCollectPoint/LocalSpecialties#nilotpalalotuszip) | Teyvat | jdbddbhd#9874 | ID47,55-57,you need to pick up yourself. |
| 2022/10/19 | ![Padisarah](../img/icons/Padisarah.png) | [Padisarah](https://github.com/Sam5440/Genshin_Impact_Teleport/tree/download/ManualCollectPoint/LocalSpecialties#padisarahzip) | Teyvat | Hieu#5027 | / |
| 2022/10/12 | ![RukkhashavaMushroom](../img/icons/RukkhashavaMushroom.png) | [Rukkhashava Mushroom](https://github.com/Sam5440/Genshin_Impact_Teleport/tree/download/ManualCollectPoint/LocalSpecialties#rukkhashavamushroomzip) |Teyvat|civicmanan#2171 | 73 pcs |
| 2022/10/12 | ![SangoPearl](../img/icons/SangoPearl.png) | [Sango Pearl](https://github.com/Sam5440/Genshin_Impact_Teleport/tree/download/ManualCollectPoint/LocalSpecialties#sangopearlzip) | Teyvat | civicmanan#2171 | / |

